import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Encoder {

    private String path;

    public Encoder(String path) {
        this.path = path;
    }

    public String[][] Read() throws IOException {
        ArrayList<ArrayList<String>> content = new ArrayList<>();
        ArrayList<String> lineFormatted = new ArrayList<>();

        try (Reader fr = new FileReader(path)) {
            BufferedReader br = new BufferedReader(fr);
            StringBuilder sb = new StringBuilder();
            String line;
            while (true) {
                line = br.readLine();
                if (line == null) {
                    break;
                }
                for (char c : line.toCharArray()) {
                    if (c == ',') {
                        if (sb.isEmpty()) {
                            lineFormatted.add("");
                        } else {
                            lineFormatted.add(sb.toString());
                            sb.setLength(0);
                        }
                    } else {
                        sb.append(c);
                    }
                }
                lineFormatted.add(sb.toString());
                sb.setLength(0);
                content.add(lineFormatted);
                lineFormatted = new ArrayList<>();
            }
        }
        String[][] result = new String[content.size()][content.get(0).size()];
        for (int i = 0; i < content.size(); i++) {
            for (int j = 0; j < content.get(0).size(); j++) {
                result[i][j] = content.get(i).get(j);
            }
        }
        return result;
    }

    public void csvInit() throws IOException{
        try (Writer fw = new FileWriter(path)) {
            BufferedWriter bw = new BufferedWriter(fw);
            bw.append("Res.Num").append(",");
            bw.append("Res.Name").append(",");
            bw.append("ResName").append(",");
            bw.append("Check-in date").append(",");
            bw.append("Check-out date").append(",");
            bw.append("Total Rooms").append(",");
            bw.append("Room type").append(",");
            bw.append("Occupancy").append(",");
            bw.append("Total cost").append("\n");
            bw.flush();
        }
    }

    public void csvWrite(List resList) throws IOException{
        csvInit();
        try (Writer fw = new FileWriter(path, true)) {
            for (Reservation reservation : resList) {
                int numOfComma = 3 - reservation.getNumOfRoom();
                BufferedWriter bw = new BufferedWriter(fw);
                bw.append(String.valueOf(reservation.getRefNo())).append(",");
                bw.append(reservation.getName()).append(",");
                bw.append(reservation.getResType()).append(",");
                bw.append(reservation.getCheckIn().toString()).append(",");
                bw.append(reservation.getCheckOut().toString()).append(",");
                bw.append(String.valueOf(reservation.getNumOfRoom())).append(",");
                bw.append(reservation.getRoomList().toTextOutput());
                for (int i = 0; i < numOfComma; i++) {
                    bw.append(",").append(",");
                }
                bw.append(String.valueOf(reservation.getTotalCost()));
                bw.append("\n");
                bw.flush();
            }
        }
    }
}