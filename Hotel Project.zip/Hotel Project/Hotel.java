import java.util.ArrayList;
import java.util.List;

public class Hotel{
    private list roomList = new ArrayList();
    
    public List getRoomList(){
        return roomList;
    }
    
    public int getTotalRooms(String roomType){
        for (HotelRoom hotelroom: roomList){
            if (hotelroom.getRoomType().equals(roomType)){
                return hotelroom.getTotalRooms();
            }
        }
        return -1;
    }
    
    public int [] getRate (String roomType){
        for (HotelRoom hotelroom : roomList){
            if (hotelroom.getRoomType().equals(roomType)){
                return hotelroom.getRate();
            }
        }
            return null;
        }
        
    public int getMaxOccupants (String roomType){ 
    for (HotelRoom hotelroom : roomList){
        if (hotelroom.getRoomType().equals(roomType)){
            return hotelroom.getMaxOccupants;
        }
    }
    return -1;
}
}
           