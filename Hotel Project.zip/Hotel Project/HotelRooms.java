import java.util.Arrays; 

public class HotelRooms{
    private String roomType;
    private int totalRooms;
    private int maxOccupants;
    private int[] rates = new int [7];
    
    public HotelRooms(String roomType, int totalRooms, int Occupants, int [] rates){
        this.roomType = roomType;
        this.totalRooms = totalRooms;
        this.maxOccupants = maxOccupants;
        this.rates = rates;
    }
    
    public String getRoomType(){
        return roomType; 
    }
    
    public int totalRooms(){
        return totalRooms;
    }
    
    public int MaxOccupants(){
        return maxOccupants;
    }
    
    public int [] getRates (){
        return rates;
    }
}