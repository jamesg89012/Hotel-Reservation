public class HotelStar{

private static Hotel hotel5star;
private static Hotel hotel4star;
private static Hotel hotel3star;

public HotelStar (Hotel hotel5star, Hotel hotel4star, Hotel hotel3star){
    HotelStar.hotel5star = hotel5star;
    HotelStar.hotel4star = hotel4star;
    HotelStar.hotel3star = hotel3star;
}

 static int getTotalRooms(String roomType) {
        if (roomType.contains("Deluxe")) {
            return hotel5Star.getTotalRooms(roomType);
        } else if (roomType.contains("Executive")) {
            return hotel4Star.getTotalRooms(roomType);
        } else {
            return hotel3Star.getTotalRooms(roomType);
        }
    }

  static int[] getRoomRate(String roomType) {
        if (roomType.contains("Deluxe")) {
            return hotel5Star.getRoomRate(roomType);
        } else if (roomType.contains("Executive")) {
            return hotel4Star.getRoomRate(roomType);
        } else {
            return hotel3Star.getRoomRate(roomType);
        }
    }
    public void showRooms3StarHotel() {
        System.out.println(hotel5Star.toString());
    }

    public void showRooms4StarHotel() {
    System.out.println(hotel4Star.toString());
    }

    public void showRooms5StarHotel() {
    System.out.println(hotel3Star.toString());
    }
}
    
    