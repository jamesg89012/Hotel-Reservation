import java.util.ArrayList;
import java.util.List;

public class ListOfRooms {

    private List rooms = new ArrayList<>();

    public List getRooms() {
        return rooms;
    }

    public int[] getTotalOccupants() {
        int[] result = new int[3];
        for (Rooms room : rooms) {
            String roomType = room.getRoomType();
            if (roomType.contains("Classic")) {
                result[0] += room.getOccupantTotal();
            } else if (roomType.contains("Executive")) {
                result[1] += room.getOccupantTotal();
            } else {
                result[2] += room.getOccupantTotal();
            }
        }
        return result;
    }

    public int[] getMaxOccupants() {
        int[] result = new int[3];
        for (Room room : rooms) {
            String roomType = r.getRoomType();
            int occ = HotelList.getMaxOccupants(roomType);
            if (roomType.contains("Classic")) {
                result[0] += occ;
            } else if (roomType.contains("Executive")) {
                result[1] += occ;
            } else {
                result[2] += occ;
            }
        }
        return result;
    }

    public void add(Room room) {
        rooms.add(room);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Room room : rooms) {
            sb.append(room.toString());
        }
        return sb.toString();
    }

    public String toTextOutput() {
        StringBuilder sb = new StringBuilder();
        for (Rooms room : rooms) {
            sb.append(room.getRoomType());
            sb.append(",");
            sb.append(room.getOccupantTotal());
            sb.append(",");
        }
        return sb.toString();
    }
}