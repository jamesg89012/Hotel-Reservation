import java.time.*;

public class Reservation {

    private String resType, name;
    private double totalCost;
    private LocalDate checkInDate, checkOutDate;
    private int RoomNumber;
    private int refNo;
    private RoomList roomList;

    public Reservation(int refNo, String name, String resType, LocalDate checkIndate, LocalDate checkOutdate,
                       int Roomnumber, RoomList roomList, double totalCost){
        this.refNo = refNo;
        this.name = name;
        this.resType = resType;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.RoomNumber = RoomNumber;
        this.roomList = roomList;
        this.totalCost = totalCost;
    }

    public String getResType() {
        return resType;
    }

    public String getName() {
        return name;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public int getRoomNumber() {
        return RoomNumber;
    }

    public int getRefNo() {
        return refNo;
    }

    public RoomList getRoomList() {
        return roomList;
    }



    public double getTotalCost() {
        return totalCost;
    }

    public int[] getTotalOccupants() {
        return roomList.getTotalOccupants();
    }

    public int[] getMaxOccupants() {
        return roomList.getMaxOccupants();
    }
}
