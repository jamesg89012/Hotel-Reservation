public class Rooms {
    private String roomType;
    private int occupantTotal;

    public Rooms(String roomType, int occupancy) {
        this.roomType = roomType;
        this.occupantTotal = occupantTotal;
    }
        public int getOccupantTotal() {
        return occupantTotal;
    }
 public String getRoomType() {
        return roomType;
    }
}